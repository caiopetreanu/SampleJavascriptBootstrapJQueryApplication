$(document).ready(function () {

	var s_qtvendmes3;
	var s_qtvendmes2;
	var s_qtvendmes1;
	var s_media;
	var s_venda_mesatual;
	var s_estoque;
	var s_diasEstoque;
	
	$('.unidade-medida').on('click', function (e) {
		e.preventDefault();
		alterarMedida({ medida : this.text });
	});

	$('.btn-filter').click(function (e) {
		e.preventDefault();
		aplicarFiltro({ });
	});

	$(document).on('click', '.marca', function(e) {
		e.preventDefault();
		aplicarFiltro({ marca : this.text });
	});

	$(document).on('click', '.marca', function(e) {
		e.preventDefault();
		aplicarFiltro({ marca : this.text });
	});

	$(document).on('click', '.cliente', function(e) {
		e.preventDefault();
		aplicarFiltro({ cliente : this.text });
	});

	$(document).on('click', '.apresentacao', function(e) {
		e.preventDefault();
		aplicarFiltro({ produto : this.text });
	});

	aplicarFiltro = function(filtro) {
		carregarFamilias(filtro);
		carregarApresentacoes(filtro);
		carregarDemandaEstoque(filtro);
		carregarCliente(filtro);
	}

	Number.prototype.format = function (n, x, s, c) {
		var re  = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
		    num = this.toFixed(Math.max(0, ~~n));

		return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
	};

	carregarFamilias = function (filtro) {

		request = $.ajax({

			method:   "POST",
			url:      "http://localhost:8080/kam/painelgerencial/familias/consultar",
			dataType: "json",
			data:     {
				login:  "testeLogin",
				filtro : filtro
			}

		})
		;

		request.done(function (res) {

			res = eval(res);

			if (res.erro == null) {

				var familias = '<table class="table table-striped"><tbody>';

				$.each(res.result.marca, function () {
					familias += '<tr><td><a href="#" class="marca">' + this + '</a></td></tr>'
				})

				familias += '</tbody></table>';
				$("#familias").html(familias);

			}

			else {
				alert(res.erro);
			}

		});

		request.fail(function (jqXHR, textStatus) {

		});

	};

	carregarApresentacoes = function (filtro) {

		request = $.ajax({

			method:   "POST",
			url:      "http://localhost:8080/kam/painelgerencial/apresentacoes/consultar",
			dataType: "json",
			data:     {
				login:  "testeLogin",
				filtro : filtro
			}

		})
		;

		request.done(function (res) {

			res = eval(res);

			if (res.erro == null) {

				var apresentacoes = '<table class="table table-striped"><tbody>';

				$.each(res.result.apresentacao, function () {
					apresentacoes += '<tr><td><a href="#" class="apresentacao">' + this + '</a></td></tr>'
				})

				apresentacoes += '</tbody></table>';
				$("#apresentacoes").html(apresentacoes);

			}

			else {
				alert(res.erro);
			}

		});

		request.fail(function (jqXHR, textStatus) {

		});

	};

	carregarDemandaEstoqueHead = function (res, demandasEstoquesBody, sum) {

		var demandasEstoquesHead =

			    '<thead>' +
			    '<tr>' +
			    '<th class="text-center">SUBTOTAL</th>' +
			    '<th class="text-center">' + Math.round(sum.s_qtvendmes3).format(0, 3, '.') + '</th>' +
			    '<th class="text-center">' + Math.round(sum.s_qtvendmes2).format(0, 3, '.') + '</th>' +
			    '<th class="text-center">' + Math.round(sum.s_qtvendmes1).format(0, 3, '.') + '</th>' +
			    '<th class="text-center">' + Math.round(sum.s_media).format(0, 3, '.') + '</th>' +
			    '<th class="text-center">' + Math.round(sum.s_venda_mesatual).format(0, 3, '.') + '</th>' +
			    '<th class="text-center">' + Math.round(sum.s_estoque).format(0, 3, '.') + '</th>' +
			    '<th class="text-center">' + Math.round(sum.s_diasEstoque).format(0, 3, '.') + '</th>' +
			    '</tr>' +
			    '<tr>' +
			    '<th>FAM&Iacute;LIA</th>' +
			    '<th class="text-center">FEV</th>' +
			    '<th class="text-center">MAR</th>' +
			    '<th class="text-center">ABR</th>' +
			    '<th class="text-center">M&Eacute;DIA</th>' +
			    '<th class="text-center">MAI</th>' +
			    '<th class="text-center">ESTOQUE ATUAL</th>' +
			    '<th class="text-center">DIAS DE ESTOQUE</th>' +
			    '</tr>' +
			    '</thead>';

		demandasEstoquesHead += demandasEstoquesBody;
		$("#demandaEstoque").html(demandasEstoquesHead);

	};

	carregarDemandaEstoqueBody = function (res) {

		var demandasEstoques = '<tbody>';

		s_qtvendmes3 = 0;
		s_qtvendmes2 = 0;
		s_qtvendmes1 = 0;
		s_media = 0;
		s_venda_mesatual = 0;
		s_estoque = 0;
		s_diasEstoque = 0;

		$.each(res.result.demandasEstoques, function () {

			var media = Math.round((this.qtvendmes3 + this.qtvendmes2 + this.qtvendmes1) / 3).format(0, 3, '.');
			var diasEstoque = media != 0 ? Math.round((this.estoque / media) * 30).format(0, 3, '.') : 0;

			s_qtvendmes3 += this.qtvendmes3;
			s_qtvendmes2 += this.qtvendmes2;
			s_qtvendmes1 += this.qtvendmes1;
			s_media += parseInt(media, 10);
			s_venda_mesatual += this.venda_mesatual;
			s_estoque += this.estoque;
			s_diasEstoque += parseInt(diasEstoque, 10);

			this.qtvendmes3 = Math.round(this.qtvendmes3).format(0, 3, '.')
			this.qtvendmes3 = Math.round(this.qtvendmes2).format(0, 3, '.')
			this.qtvendmes3 = Math.round(this.qtvendmes1).format(0, 3, '.')
			this.venda_mesatual = Math.round(this.venda_mesatual).format(0, 3, '.')
			this.estoque = Math.round(this.estoque).format(0, 3, '.')

			var sum = {};

			demandasEstoques += '' +
				'<tr>' +
				'<td>' + this.produto + '</td>' +
				'<td class="text-center">' + this.qtvendmes3 + '</td>' +
				'<td class="text-center">' + this.qtvendmes2 + '</td>' +
				'<td class="text-center">' + this.qtvendmes1 + '</td>' +
				'<td class="text-center">' + media + '</td>' +
				'<td class="text-center">' + this.venda_mesatual + '</td>' +
				'<td class="text-center">' + this.estoque + '</td>' +
				'<td class="text-center">' + diasEstoque + '</td>' +
				'</tr>';

		});

		sum = {
			s_qtvendmes3:     s_qtvendmes3,
			s_qtvendmes2:     s_qtvendmes2,
			s_qtvendmes1:     s_qtvendmes1,
			s_media:          s_media,
			s_venda_mesatual: s_venda_mesatual,
			s_estoque:        s_estoque,
			s_diasEstoque:    s_diasEstoque
		};

		demandasEstoques += '</tbody:';
		carregarDemandaEstoqueHead(res, demandasEstoques, sum);

	};

	carregarDemandaEstoque = function (filtro) {

		request = $.ajax({

			method:   "POST",
			url:      "http://localhost:8080/kam/painelgerencial/demandaestoque/consultar",
			dataType: "json",
			data:     {
				login:  "testeLogin",
				filtro : filtro
			}

		});

		request.done(function (res) {

			res = eval(res);

			if (res.erro == null) {
				carregarDemandaEstoqueBody(res);
				atualizarSimulador();
			}

			else {
				alert(res.erro);
			}

		});

		request.fail(function (jqXHR, textStatus) {

		});

	};

	atualizarSimulador = function () {

		$("#realizado").text((s_qtvendmes3 + s_qtvendmes2 + s_qtvendmes1 + s_venda_mesatual).format(0, 3, '.'));
		$("#mesAtual").text(s_venda_mesatual.format(0, 3, '.'));
		$("#mediaProjetada").text(s_media.format(0, 3, '.'));

	};

	carregarCliente = function(filtro) {

		request = $.ajax({

			method:   "POST",
			url:      "http://localhost:8080/kam/painelgerencial/clientes/consultar",
			dataType: "json",
			data:     {
				login:  "testeLogin",
				filtro : filtro
			}

		});

		request.done(function (res) {

			res = eval(res);

			if (res.erro == null) {

				var clientes = '<table class="table table-striped"><tbody>';

				$.each(res.result.cliente, function () {
					clientes += '<tr><td><a href="#" class="cliente">' + this + '</a></td></tr>'
				})

				clientes += '</tbody></table>';
				$("#clientes").html(clientes);

			}

			else {
				alert(res.erro);
			}

		});

		request.fail(function (jqXHR, textStatus) {

		});

	};

	$("#regional").html($("regional").html());

	carregarFamilias();
	carregarApresentacoes();
	carregarDemandaEstoque();
	carregarCliente();

})
;